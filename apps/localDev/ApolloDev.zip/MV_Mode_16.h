/* MV_Mode_16.h - Neuron-C Network Variable Type header file */

#ifndef _MV_Mode_16_h_enumeration
#define _MV_Mode_16_h_enumeration

/* The enum definition below defines the enumeration to be used */
/* with tagname "MV_Mode_16" enum set, index 2 */

typedef enum MV_Mode_16 {
 	/*   1 */ 	OFF = 1,
 	/*   2 */ 	Auto = 2,
 	/*   3 */ 	Cool = 3,
 	/*   4 */ 	Heat = 4,
 	/*  -1 */ 	MEM_NUL = -1
} MV_Mode_16;

/* end of: MV_Mode_16 */
#endif
