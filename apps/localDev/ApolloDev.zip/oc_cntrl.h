/* oc_cntrl.h - Neuron-C Network Variable Type header file */

#ifndef _oc_cntrl_h_enumeration
#define _oc_cntrl_h_enumeration

/* The enum definition below defines the enumeration to be used */
/* with tagname "oc_cntrl" enum set, index 5 */

typedef enum oc_cntrl {
 	/*   0 */ 	OCC_OCCUP = 0, 	/* Occupancy */
 	/*   1 */ 	OCC_SCENE = 1, 	/* Scene */
 	/*   2 */ 	OCC_LEVEL = 2, 	/* Level */
 	/*  -1 */ 	MEM_NUL = -1
} oc_cntrl;

/* end of: oc_cntrl */
#endif
