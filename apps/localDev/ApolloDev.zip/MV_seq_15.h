/* MV_seq_15.h - Neuron-C Network Variable Type header file */

#ifndef _MV_seq_15_h_enumeration
#define _MV_seq_15_h_enumeration

/* The enum definition below defines the enumeration to be used */
/* with tagname "MV_seq_15" enum set, index 1 */

typedef enum MV_seq_15 {
 	/*   1 */ 	Cooling = 1, 	/* Cooling only */
 	/*   2 */ 	Heating = 2, 	/* Heating onlyt */
 	/*   3 */ 	Cooling_Reheat = 3, 	/* Coolling with reheat */
 	/*   4 */ 	Heating_Reheat = 4, 	/* Heating with Reheat */
 	/*   5 */ 	Cool_Heat4P = 5,
 	/*   6 */ 	Cool_Heat4P_RH = 6,
 	/*  -1 */ 	MEM_NUL = -1
} MV_seq_15;

/* end of: MV_seq_15 */
#endif
