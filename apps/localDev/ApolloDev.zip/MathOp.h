/* MathOp.h - Neuron-C Network Variable Type header file */

#ifndef _MathOp_h_enumeration
#define _MathOp_h_enumeration

/* The enum definition below defines the enumeration to be used */
/* with tagname "MathOp" enum set, index 1 */

typedef enum MathOp {
 	/*   0 */ 	OP_ADD = 0, 	/* Add */
 	/*   1 */ 	OP_SUB = 1, 	/* Subtract */
 	/*   2 */ 	OP_MULT = 2, 	/* Multiply */
 	/*   3 */ 	OP_DIV = 3, 	/* Divide */
 	/*  -1 */ 	MEM_NUL = -1
} MathOp;

/* end of: MathOp */
#endif
