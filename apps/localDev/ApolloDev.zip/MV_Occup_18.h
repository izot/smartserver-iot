/* MV_Occup_18.h - Neuron-C Network Variable Type header file */

#ifndef _MV_Occup_18_h_enumeration
#define _MV_Occup_18_h_enumeration

/* The enum definition below defines the enumeration to be used */
/* with tagname "MV_Occup_18" enum set, index 3 */

typedef enum MV_Occup_18 {
 	/*   1 */ 	Local_Occup = 1,
 	/*   2 */ 	Occupied = 2,
 	/*   3 */ 	Unoccupied = 3,
 	/*  -1 */ 	MEM_NUL = -1
} MV_Occup_18;

/* end of: MV_Occup_18 */
#endif
