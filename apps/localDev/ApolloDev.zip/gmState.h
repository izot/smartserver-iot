/* gmState.h - Neuron-C Network Variable Type header file */

#ifndef _gmState_h_enumeration
#define _gmState_h_enumeration

/* The enum definition below defines the enumeration to be used */
/* with tagname "gmState" enum set, index 4 */

typedef enum gmState {
 	/*   0 */ 	GMS_PAUSED = 0,
 	/*   1 */ 	GMS_STARTED = 1,
 	/*   2 */ 	Member_2 = 2,
 	/*  -1 */ 	GMS_NULL = -1
} gmState;

/* end of: gmState */
#endif
