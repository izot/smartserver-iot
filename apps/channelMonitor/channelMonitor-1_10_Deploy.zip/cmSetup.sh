#!/bin/bash
# This script is used to install the channel monitor service,  Run as root
echo "Install channelMonitor service..."
echo "Scipt Version: 1.03"
echo "Three parameters: \$1: [Apollo pwd], \$2: [R|B|C]:, \$3: [update]"
echo "---------------------------------"
# 
PASS=$1
ROUTERMODE="R"
RAWMODE=0;
UPDATE=$3
usage () {
    echo "Usage: $0 [Apollo pwd] [R|B|C] [update]"
    exit 1
}
if [ -z $PASS ]
then
   echo "Error: This script requires user parameters"
   exit 1
fi
if [ -z $2 ]
then
   ROUTERMODE="R"
else
   case "$2" in
      (r|R)
         ROUTERMODE="R" 
         RAWMODE=0 ;;
      (b|B)
         ROUTERMODE="B" 
         RAWMODE=1 ;;   
      (c|C)
         ROUTERMODE="C"
         RAWMODE=2 ;;
      (*) usage ;;    
   esac
fi
echo "Using router mode: $ROUTERMODE"
if [ -z $3 ]
then
   UPDATE=0
else
   UPDATE=1   
fi
echo "Router configured as: $2"
APP_DIR="$APOLLO_DATA/apps"
A_SETUP="channelMonitor"
LOG_DIR="/media/sdcard/app_logdata"
if [ ! -d "$APP_DIR" ] || [ ! -d $APP_DIR/$A_SETUP ] 
then
   echo "Creating install directory $APP_DIR"
   mkdir -p "$APP_DIR/$A_SETUP"
   UPDATE=0
   [ ! -d "$LOG_DIR" ] && mkdir -p "$LOG_DIR"
   chown apollo:apollo "$LOG_DIR"
   chmod -R 775 "$LOG_DIR"
fi   
cp ./channelMonitorPackage.zip "$APP_DIR/$A_SETUP"
cd "$APP_DIR/$A_SETUP"
unzip -o ./channelMonitorPackage.zip
rm ./channelMonitorPackage.zip
supervisorctl stop channelMon
mv -f ./channelMon.conf /etc/supervisor/conf.d
chown apollo:apollo *.*
chmod -R 775 $APP_DIR
chmod 666 channelMonitor.js
chown root:apollo /etc/supervisor/conf.d/channelMon.conf
chmod 664 /etc/supervisor/conf.d/channelMon.conf
mv -f ./channelMon-ctl /usr/sbin
chmod 755 /usr/sbin/channelMon-ctl
if [ $UPDATE -eq 0 ]
then
   echo "Moving ApolloDev resources (1.32) to $APOLLO_DATA/dtp-files.d"
   mv -f ./ApolloDev_1_32.dtp $APOLLO_DATA/dtp-files.d
   echo "Moving device type files to $APOLLO_DATA/dtp-files.d"
   mv -f ./channelMon.dtp $APOLLO_DATA/dtp-files.d
   chown apollo:apollo $APOLLO_DATA/dtp-files.d/channelMon.dtp
   chmod 666 $APOLLO_DATA/dtp-files.d/channelMon.dtp
   chown apollo:apollo $APOLLO_DATA/dtp-files.d/ApolloDev_1_32.dtp
   chmod 666 $APOLLO_DATA/dtp-files.d/ApolloDev_1_32.dtp
   echo "Loading ApolloDev resources"
   dtp-loader http://localhost:8181 apollo ea1 /var/apollo/data/dtp-files.d/ApolloDev_1_32.dtp
   echo "Loading channelMon package"
   dtp-loader http://localhost:8181 apollo ea1 /var/apollo/data/dtp-files.d/channelMon.dtp
   sleep 5
   echo "Enable eth0 IP852 port 1628"
   ufw allow 1628
   echo "Creating IP-70 side of IP-852 router"
   mosquitto_pub -t glp/0/$APOLLO_INSTALL_CODE/rq/dev/lon/ip852NS_eth0/do -m '{"action": "create", "args": { "type": "9000010500C08520", "unid": "auto", "lon.attach": "local"}}'
   sleep 3s
   echo "Creating Farside of IP-852 router, configured as a Repeater"
   mosquitto_pub -t glp/0/$APOLLO_INSTALL_CODE/rq/dev/lon/ip852FS_eth0/do -m '{"action": "create", "args": { "provision": true, "type": "9000010500C08520", "unid": "auto","lon.attach": "ip852NS_eth0", "routing": { "media": "IP-852", "interface": "eth0", "ipPort": 1628, "mode": "Repeater"}}}'
fi

sed -i "s/channelMonitor.js.*/channelMonitor.js true $RAWMODE/g" /etc/supervisor/conf.d/channelMon.conf
sed -i "s/autostart=.*/autostart=true/g" /etc/supervisor/conf.d/channelMon.conf

echo "Starting services."
sleep 30s
supervisorctl reload
echo "ChannelMonitor Service installed."
cd ~
