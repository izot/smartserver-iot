'use strict';
const mqtt = require('mqtt');
const { execSync } = require("child_process");
const fs = require('fs'); 
const { notDeepEqual } = require('assert');

const version = '1.00.005';

let logFilePath = `/media/sdcard/app_logdata/`;
let startupPause = 240;
let logRecCache = new Array();
let now = new Date();
let provisioned = 'unknown';
let gmState = 'unknown';
let createPending = false;
let delayStart = true;
const logHouseKeepingTmo = 24 * 60 * 60 * 1000 ;
let currentDate;
let args = process.argv.slice(2);
let attached = true;
let myAppIf = {
        appPID : '9000010600058518',
        fbName : 'channelMonitor',
        devHandle : 'chMon-1',       // Your choice here, but must not already exist on your target SmartServer    
};    

function cmdBanner (){
    let now = new Date()
    currentDate = now.getDate();
    console.log(`\n[${now.toLocaleString()}] - channelMonitor.js - version: ${version}`); 
    logRecCache.push (`${now.toLocaleString()},INFO,Application startup\r\n`);
};
cmdBanner();

if (args.length == 1) {
    delayStart= args[0];                       
}
// Blocking delay to hold off until the rest of the SIOT services are running
// delayStart is true by default.  Windows debugging should provide a third
// commannd argument of "false"
if ((process.platform == 'linux') && (delayStart == true)) {
    console.log(`Allowing SIOT processes to initialize.  Sleep for: ${(startupPause ).toString()}s`);
    // Only in linux
    execSync("sleep " +  (startupPause).toString());  // 10 Minutes required for large systems
}
let glpPrefix='glp/0';  // this will include the sid once determined
const client = mqtt.connect(`mqtt://127.0.0.1:1883`);
//const client = mqtt.connect(`mqtt://192.168.10.202:1883`);
// Subscribe to the segment ID topic.
const sidTopic = `${glpPrefix}/././sid`;

client.subscribe(
    sidTopic,
    (error) => {
        if (error) {
            console.log(error);
        }
    }
);
// File housekeeping on 24hr interval.  Remove log files on the sdcard that are older than 60days
if (process.platform == 'linux') {
    // Daily log file house keeping will delete files that are older that 12m
    setInterval (() => {
        exec("find /media/sdcard/app_logdata -type f -mtime +60 -delete",(error, stdout, stderr)=> {
            if (error){
                //console.log(`File housekeeper error: $(error.message)` );
                return;
            }
            if (stderr) {
                //console.log(`File housekeeper stderr: $(error.message)` );
                return;
            }
            if (stdout) {
                //console.log(`File housekeeper stdout: $(error.message)` );
                return;
            }
        });
    },logHouseKeepingTmo);
};
// This function will fire if the internal device for this application does not exist.
// This is the case the very first time this application runs on the target SmartServer.  
// This device will exist on the SmartServer until it is deleted by user action in the CMS
// or the SmartServer Apollo-reset normal... is executed.
const myDevCreateTmo = setTimeout (() => {
    console.log(`Creating the internal device: ${myAppIf.devHandle} based on PID: ${myAppIf.appPID}`);
    let createMyAppMsg = {
        action: 'create',
        args: {
            unid: 'auto',
            type: myAppIf.appPID,
            'lon.attach': 'local',
            provision : true
            }
        } // CreateMyAppMsg {}
    client.publish(
        `${glpPrefix}/rq/dev/lon/${myAppIf.devHandle}/do`,
        JSON.stringify(createMyAppMsg)
    );
    provisioned = 'unknown';
    createPending = true;
    let setCfg = {
        name: `${myAppIf.devHandle}`,
        desc: 'U60 USB traffic monitor'
    }
    client.publish(
        `${glpPrefix}/rq/dev/lon/${myAppIf.devHandle}/cfg`,
        JSON.stringify(setCfg)
    );
    const waitForDeviceCreate = setInterval (() => {
        if (!createPending) {
            console.log (`The device chMon-1 has been created and provisioned.`);
            clearInterval(waitForDeviceCreate);
            //process.exit(1);
        }    
        }, 2000);
    },  // IAP/MQ do {action: 'create'} 
    15000
); //10s timeout to determine if the Internal device exists

let updatedEvtTopic = '';
let devStsTopic = '';
let fbIfcTopic = '';
let logInfo = true;
function handleSid (sidMsg) {
    // Assuming the SID topic is a string sidMsg
    let nowTs = new Date(); // Seconds TS good enough
    if (typeof(sidMsg) === typeof('xyz')) {
        if (sidMsg.length > 0) {
            glpPrefix += `/${sidMsg}`;
            console.log(`[${nowTs.toLocaleString()}] - SmartServer SID: ${sidMsg}`);
            updatedEvtTopic = `${glpPrefix}/ev/updated/dev/lon/type/+`;
            devStsTopic = `${glpPrefix}/fb/dev/lon/+/sts`;
            fbIfcTopic = `${glpPrefix}/fb/dev/lon/${myAppIf.devHandle}/if/${myAppIf.fbName}/+`;
            //client.subscribe (updatedEvtTopic);
            client.subscribe (devStsTopic);    
            client.unsubscribe (sidTopic);
        } else {
            console.log(`Redundant SID topic message`);
        }
    } 
};

function publish (value, dp, index) {
    //console.log(`Publish: ${dp} block: ${index} - ${JSON.stringify(value)}`);
    client.publish (
        `${glpPrefix}/rq/dev/lon/${myAppIf.devHandle}/if/${myAppIf.fbName}/${index}/${dp}/value`,
        JSON.stringify(value),
        {qos:1},
        (err) => {
             if(err !=null)
                 console.error (`Failed to update: ${outputPnt} : ${err}`);
         }
    );
}

class ifStats {
    rxPkts = -1;
    rxBytes = -1;
    rxErrors = -1;
    rxDrop = -1;
    rxOverrun = -1;
    rxFrame = -1;
    txPkts = -1;
    txBytes = -1;
    txErrors = -1;
    txDrop = -1;
    txOverrun = -1;
    collisions = -1;
    txPPS = -1;
    rxPPS = -1;
    txBPS = -1;
    rxBPS = -1;
    lastTs = 0;
    dropExcessiveCnt = 0;
    stackDown = false;
    ifcFlow = 0;
    currentAlarm = { 
        alarm_type: 'AL_SYSTEM_INFO',
        priority_level: 'PR_LEVEL_0',
        alarm_time: 0,
        milliseconds: 0,
        sequence_number: 0,
        description:''
    };
    ifcData = {
        rxPackets: 0,
        rxBytes: 0,
        txPackets: 0,
        txBytes: 0,
        rxErrors: 0,
        txErrors: 0,
        rxDropped: 0,
        txDropped: 0,
        rxOverrun: 0,
        txOverrun: 0
    };
    ifcTraffic = {
        rxPps: 0,
        txPps: 0
    };
    lowWater = {
        timeStamp:'',
        rxPktPS: 10000,
        txPktPS: 10000
    };
    highWater = {
        timeStamp:'',
        rxPktPS: 0,
        txPktPS: 0
    };
    constructor (ifc,rate,block) {
        this.rxPkts = -1;
        this.rxBytes = -1;
        this.rxErrors = -1
        this.rxDrop = -1;
        this.rxOverrun = -1;
        this.rxFrame = -1;
        this.txPkts = -1;
        this.txBytes = -1;
        this.txErrors = -1;
        this.txDrop = -1;
        this.txOverrun = -1;
        this.collisions = -1;
        this.lastTs = 0;
        this.ifc = ifc;
        this.block = block;
        this.timeout = 0;
        this.interfaceConnected = true;
        this.dropLimit = Math.min(10 * rate, 300);
    }
    
    updateStats(ifcfgOutput) {
        let d = new Date();
        let outputLines = ifcfgOutput.split(/[\r\n]+/);
        let firstRead = this.rxPkts == -1;
        let deltaDropTotal = 0;

        // lon0: flags=67<UP,BROADCAST,RUNNING>  mtu 1280
        // inet 44.25.199.120  netmask 255.255.255.0  broadcast 44.25.199.255
        // unspec 00-D0-71-14-BF-3A-00-00-00-00-00-00-00-00-00-00  txqueuelen 10  (UNSPEC)
        // RX packets 316  bytes 8497 (8.4 KB)
        // RX errors 0  dropped 0  overruns 0  frame 0
        // TX packets 5387  bytes 7980 (7.9 KB)
        // TX errors 0  dropped 5 overruns 0  carrier 0  collisions 0

        if (firstRead) {
            this.rxPkts = parseInt(outputLines[3].trim().split(/(\s+)/)[4],10);
            this.rxBytes = parseInt(outputLines[3].trim().split(/(\s+)/)[8],10);
            this.rxErrors = parseInt(outputLines[4].trim().split(/(\s+)/)[4],10);
            this.rxDrop = parseInt(outputLines[4].trim().split(/(\s+)/)[8],10);
            this.rxOverrun =  parseInt(outputLines[4].trim().split(/(\s+)/)[12],10);
            this.rxFrame =  parseInt(outputLines[4].trim().split(/(\s+)/)[16],10);
            this.txPkts =  parseInt(outputLines[5].trim().split(/(\s+)/)[4],10);
            this.txBytes = parseInt(outputLines[5].trim().split(/(\s+)/)[8],10);
            this.txErrors = parseInt(outputLines[6].trim().split(/(\s+)/)[4],10);
            this.txDrop = parseInt(outputLines[6].trim().split(/(\s+)/)[8],10);
            this.txOverrun =  parseInt(outputLines[6].trim().split(/(\s+)/)[12],10);
            this.collisions =  parseInt(outputLines[6].trim().split(/(\s+)/)[20],10);
            this.lastTs = d.getTime();
            this.timeout = 0; 
            return;
        }
        let tmDelta = d.getTime() - this.lastTs;
        let delta = 0;
        this.lastTs = d.getTime();
        let lastValue = this.rxPkts;
        this.rxPkts = parseInt(outputLines[3].trim().split(/(\s+)/)[4],10);
        this.ifcData.rxPackets = this.rxPkts;
        delta = this.rxPkts - lastValue;
        this.rxPPS = Math.round(delta/tmDelta * 10000)/10;
        this.ifcTraffic.rxPps = this.rxPPS;
        lastValue = this.rxBytes;
        this.rxBytes =  parseInt(outputLines[5].trim().split(/(\s+)/)[8],10);
        this.ifcData.rxBytes = this.rxBytes;
        delta = this.rxBytes - lastValue;
        this.rxBPS = delta/tmDelta * 1000;
        lastValue = this.txPkts;
        this.txPkts =  parseInt(outputLines[5].trim().split(/(\s+)/)[4],10);
        this.ifcData.txPackets = this.txPkts;
        delta = this.txPkts - lastValue;
        this.txPPS = Math.round(delta/tmDelta * 10000)/10;
        this.ifcTraffic.txPps = this.txPPS;
        this.ifcFlow = this.rxPPS + this.txPPS;
        lastValue = this.txBytes;
        this.txBytes =  parseInt(outputLines[5].trim().split(/(\s+)/)[8],10);
        this.ifcData.txBytes= this.txBytes;
        delta = this.txBytes - lastValue;
        this.txBPS = delta/tmDelta * 1000;
        lastValue = this.rxErrors;
        this.rxErrors = parseInt(outputLines[4].trim().split(/(\s+)/)[4],10);
        this.ifcData.rxErrors = this.rxErrors;
        delta = this.rxErrors - lastValue;
        if (delta > 0) {
            this.currentAlarm.alarm_time = this.lastTs / 1000;
            this.currentAlarm.sequence_number = ++this.currentAlarm.sequence_number % 255;
            this.currentAlarm.description = `RXerr: ${delta}`;
            publish(this.currentAlarm,'Alarm_o', this.block);
            logRecCache.push(`${d.toLocaleString()},ALARM,${this.currentAlarm.description}\r\n`);         
        }
        lastValue = this.rxDrop;
        this.rxDrop = parseInt(outputLines[4].trim().split(/(\s+)/)[8],10);
        this.ifcData.rxDropped = this.rxDrop;
        delta = this.rxDrop - lastValue;
        if (delta > 0) {
            this.currentAlarm.alarm_time = this.lastTs / 1000;
            this.currentAlarm.sequence_number = ++this.currentAlarm.sequence_number % 255;
            this.currentAlarm.description = `RXdrop: ${delta}`;
            publish(this.currentAlarm,'Alarm_o', this.block); 
            deltaDropTotal += delta;
            logRecCache.push(`${d.toLocaleString()},ALARM,${this.currentAlarm.description}\r\n`);     
        }
        lastValue = this.rxOverrun;
        this.rxOverrun = parseInt(outputLines[4].trim().split(/(\s+)/)[12],10);
        this.ifcData.rxOverrun = this.rxOverrun;
        delta = this.rxOverrun - lastValue;
        if (delta > 0) {
            this.currentAlarm.alarm_time = this.lastTs / 1000;
            this.currentAlarm.sequence_number = ++this.currentAlarm.sequence_number % 255;
            this.currentAlarm.description = `RXovr: ${delta}`;
            publish(this.currentAlarm,'Alarm_o', this.block); 
            logRecCache.push(`${d.toLocaleString()},ALARM,${this.currentAlarm.description}\r\n`);     
        }
        lastValue = this.txErrors;
        this.txErrors = parseInt(outputLines[6].trim().split(/(\s+)/)[4],10);
        this.ifcData.txErrors = this.txErrors;
        delta = this.txErrors - lastValue;
        if (delta > 0) {
            this.currentAlarm.alarm_time = this.lastTs / 1000;
            this.currentAlarm.sequence_number = ++currentAlarm.sequence_number % 255;
            this.currentAlarm.description = `TXerr: ${delta}`;
            publish(this.currentAlarm,'Alarm_o', this.block); 
            logRecCache.push(`${d.toLocaleString()},ALARM,${this.currentAlarm.description}\r\n`);     
        }
        lastValue = this.txDrop;
        this.txDrop = parseInt(outputLines[6].trim().split(/(\s+)/)[8],10);;
        this.ifcData.txDropped = this.txDrop;
        delta = this.txDrop - lastValue;
        if (delta > 0) {
            this.currentAlarm.alarm_time = this.lastTs / 1000;
            this.currentAlarm.sequence_number = ++this.currentAlarm.sequence_number % 255;
            this.currentAlarm.description = `TXdrop: ${delta}`;
            publish(this.currentAlarm,'Alarm_o', this.block);  
            deltaDropTotal += delta; 
            logRecCache.push(`${d.toLocaleString()},ALARM,${this.currentAlarm.description}\r\n`);     
        }
        if (deltaDropTotal > this.dropLimit) {
            ++this.dropExcessiveCnt;
        } else {
            if (this.dropExcessiveCnt) 
                --this.dropExcessiveCnt;
        }
        lastValue = this.txOverrun;
        this.txOverrun =  parseInt(outputLines[6].trim().split(/(\s+)/)[12],10);
        this.ifcData.txOverrun = this.txOverrun;
        delta = this.txOverrun - lastValue;
        if (delta > 0) {
            this.currentAlarm.alarm_time = this.lastTs / 1000;
            this.currentAlarm.sequence_number = ++this.currentAlarm.sequence_number % 255;
            this.currentAlarm.description = `TXovr: ${delta}`;
            publish(this.currentAlarm,'Alarm_o', this.block);  
            logRecCache.push(`${d.toLocaleString()},ALARM,${this.currentAlarm.description}\r\n`);     
        }
        // Watermark checks
        if ((this.rxPPS + this.txPPS) < (this.lowWater.rxPktPS + this.lowWater.txPktPS)) {
            this.lowWater.timeStamp = d.toLocaleString();
            this.lowWater.rxPktPS = this.rxPPS;
            this.lowWater.txPktPS = this.txPPS;
            publish(this.lowWater,'LowWater_o',this.block);
            logRecCache.push(`${d.toLocaleString()},INFO,Lowwater set: RX- ${this.rxPPS} TX: ${this.txPPS} \r\n`);      
        }
        if ((this.rxPPS + this.txPPS) > (this.highWater.rxPktPS + this.highWater.txPktPS)) {
            this.highWater.timeStamp = d.toLocaleString();
            this.highWater.rxPktPS = this.rxPPS;
            this.highWater.txPktPS = this.txPPS;
            publish(this.highWater,'HighWater_o',this.block);
            logRecCache.push(`${d.toLocaleString()},INFO,Highwater set: RX- ${this.rxPPS} TX: ${this.txPPS} \r\n`);     
        }
        publish(this.ifcData,'ifcData_o',this.block);
        publish(this.ifcTraffic,'ifcTraffic_o',this.block);
        publish(this.ifcFlow, 'ifcFlow_o', this.block);
        if (logInfo || currentDate != d.getDate()) {
            logInfo = false;
            currentDate = d.getDate();
            logRecCache.push(`${d.toLocaleString()},INFO,RX Pkts: ${this.rxPkts} TX Pkts: ${this.txPkts}, RX PPS: ` +
                `${this.rxPPS} TX PPS: ${this.txPPS} \r\n`);   
            logRecCache.push(`${d.toLocaleString()},INFO,RX Err: ${this.rxErrors} RX Drop: ${this.rxDrop}, RX Overrun : ` +
                `${this.rxOverrun} RX Frame: ${this.rxFrame} \r\n`);   
            logRecCache.push(`${d.toLocaleString()},INFO,TX Err: ${this.txErrors} TX Drop: ${this.txDrop}, TX Overrun : ` +
                `${this.txOverrun} TX Collisions: ${this.collisions} \r\n`);   
        }
    }
}

const interfaces = new Map();
let stackDown = false;
let testCount = 0;
let interfaceConnected = true; 

function getIfStats (statObj) {
    let ifconfigRes = '';
    let now = new Date();
    try {
        if (process.platform == 'linux') {
            if (stackDown)
                return;
            //++testCount;
            ifconfigRes = execSync('ifconfig ' + statObj.ifc, {encoding:'utf-8'});    
            statObj.updateStats(ifconfigRes);
            // 
            if (statObj.dropExcessiveCnt > 5 /*|| testCount == 20*/) {
                stackDown = true;
                execSync ('supervisorctl stop lon:*',{encoding:'utf-8'});
                logRecCache.push (`${now.toLocaleString()},ALARM, Stopping LT Stack.\r\n`);
                console.log (`[${now.toLocaleString()}] Stopping LT Stack`);
                statObj.dropExcessiveCnt = 0;
                // Restart he LT stack in 150s
                setTimeout (() => {
                    let now = new Date();
                    logRecCache.push (`${now.toLocaleString()},ALARM, Starting LT Stack.\r\n`);
                    console.log (`[${now.toLocaleString()}] Starting LT Stack`);
                    stackDown = false;
                    execSync ('supervisorctl start lon:*',{encoding:'utf-8'});
                },150000);
            }
            // Logging interface alarms and significant events.
            let logRecords = logRecCache.length;
            if (logRecords > 0) {
                let activeLogFname = `${(now.getMonth()+1).toString().padStart(2,'0')}-${now.getDate().toString().padStart(2,'0')}-` +
                    `${now.getFullYear()}_channelMod.csv`;
                let logStream = fs.createWriteStream(logFilePath + activeLogFname, {flags: 'a+'});
                while (logRecCache.length) {
                    logStream.write(logRecCache.shift(),"UTF8");
                };
                logStream.end();
                logStream.on('error',(error) => {
                        console.log(`Error writing Log data: ${error.stack}`)
                }); 
                console.log (`[${now.toLocaleString()}] - Logged: ${logRecords} records`);   
            }
            //console.log(`ifc: ${statObj.ifc}`);
        } else {
            console.log ('By passing execSycn ifconfig');
        }
    }  catch (err) {
        console.log (`The interface: ${statObj.ifc} does not exist ${err.message}`);
        interfaceConnected = false;
    }         
}

client.on(
    'message', 
    (topic, message) => {
    try {
        const payload = JSON.parse(message);
        let tsNow = new Date();
        
        if (topic === sidTopic) {
            // Assuming the SID topic is a string payload
            handleSid(payload);
        }  
        if (topic.endsWith (`${myAppIf.devHandle}/sts`)) {
            if (payload.state != 'deleted')
                clearTimeout(myDevCreateTmo);
            provisioned = payload.state;
            if (provisioned != 'deleted')
                gmState = payload.health;
            console.log (`${myAppIf.devHandle} - State: ${provisioned} - Health: ${gmState} `); 
            if (provisioned == 'provisioned') {
                client.subscribe (fbIfcTopic);
            }
            if (createPending) {
                createPending = false;
            }              
        } 
        
        // Determine the enable and the configured sampling interval
        if (topic.includes (`fb/dev/lon/${myAppIf.devHandle}/if/${myAppIf.fbName}`)) {
            let blockIndex = parseInt(topic.split('/')[9],10);
            console.log(`cpEnable: ${payload.cpEnable.value} on block: ${blockIndex}`);
            if (payload.cpEnable.value == 1 ) {
                if (interfaces.has(blockIndex.toString(10))) {
                    console.log (`Monitoring active on channelMonitor: ${blockIndex}`);
                    return; // Already monitoring
                }
                let ifc = new ifStats(payload.cpInterface.value.ifcName,payload.cpSampleRate.value,blockIndex);
                // Read the ifconfig for the baseline, and schedule the next
                getIfStats(ifc); 
                //if (interfaceConnected){
                    interfaces.set(blockIndex.toString(10),ifc);
                    console.log(`Monitoring: ${ifc.ifc} at: ${payload.cpSampleRate.value} seconds.`)
                    ifc.timeout = setInterval (getIfStats, payload.cpSampleRate.value * 1000, ifc);
                //}
            } else if (payload.cpEnable.value == 0) {
                if (interfaces.has(blockIndex.toString(10))) {
                    let ifc = interfaces.get(blockIndex.toString(10));
                    clearInterval(ifc.timeout);
                    interfaces.delete(blockIndex.toString(10));
                    console.log(`Stopping Monitoring block: ${blockIndex}`);
                }
            }
        }

    } catch(error) {
        console.error(`MQTT Message: ${error.stack}`);
    }
}   // onMessage handler
);  // onMessage registration