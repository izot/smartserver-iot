/*   
    Timezone conversion

*/
    
var g_sTimezone = "";

function convertDateToLocalFormatStr(d) {
    var sResult = "";
    var d = new Date();
    if(g_sTimezone.includes("Russia")) {
        sResult = d.getFullYear().toString() + "-" +  (d.getMonth() + 1).toString() + "-" + d.getDate().toString();
    }
    else {
        sResult = d.getFullYear().toString() + "-" +  (d.getMonth() + 1).toString().padStart(2,0) + "-" + d.getDate().toString().padStart(2,0);
    }
    return sResult;
}
