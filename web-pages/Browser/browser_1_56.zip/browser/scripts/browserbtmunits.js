
/*
 *	Copyright (C) 2023 EnOcean GmbH.  All rights reserved.
 *	
 *	Use of this code is subject to your compliance with the terms of the 
 *	EnOcean Example Software License Agreement which is available at
 *	https://enoceanwiki.atlassian.net/wiki/spaces/LON/pages/2425260/Example+Software+License+Agreement.
*/
var btmUnits = [ //-- MUST BE LOWER CASE
    ["degrees celsius", "degrees-celsius"],
    ["degrees kelvin", "degrees-kelvin"],
    ["degrees celsius", "degrees-fahrenheit"],
    ["liters", "liters"],
    ["milliamperes", "milliamperes"],
    ["amperes", "amperes"],
    ["ohms", "ohms"],
    ["volts", "volts"],
    ["kilovolts", "kilovolts"],
    ["watts", "watts"],
    ["kilowatts", "kilowatts"],
    ["lux", "luxes"],
    ["% of full level", "percent"],
    ["% of full scale", "percent"],
    ["milliseconds", "milliseconds"],
    ["seconds", "seconds"],
    ["minutes", "minutes"],
    ["hours", "hours"],
    ["days", "days"],
    ["weeks", "weeks"],
    ["months", "months"],
    ["years", "years"],
    ["hertz","hertz"],
    ["kilohertz","kilohertz"],
    ["megahertz","megahertz"]
]
var btmUnitsSnvtType = [  // sometimes units are only determined by SNVT type -- SNVT/UNVT/UCPT/SCPT keep case, units must be Lower case
    ["SNVT_angle_deg", "degrees-angular"],
    ["SNVT_str_asc", "no-units"]
]
var btmUnitsNoUnits = [  // enums are no-units  -- MUST BE LOWER CASE
    "state code", 
    "boolean",
    "alarm value",
    "object index",
    "type index",
    "bytes",
    "file scope",
    "count"
]
var btmUnitsStartsWithStringNoUnits = [  // enums are no-units -- MUST BE LOWER CASE
    "array of", 
]
var btmUnitsContainsStringNoUnits = [  // enums are no-units -- MUST BE LOWER CASE
    "-bit address value"
]
