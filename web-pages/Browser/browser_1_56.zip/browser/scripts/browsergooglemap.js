/*
 *	Copyright (C) 2023 EnOcean GmbH.  All rights reserved.
 *	
 *	Use of this code is subject to your compliance with the terms of the 
 *	EnOcean Example Software License Agreement which is available at
 *	https://enoceanwiki.atlassian.net/wiki/spaces/LON/pages/2425260/Example+Software+License+Agreement.
 */
// Initialize and add the map
function googleMapInitMap(uluru) {
  // The location of Uluru
  //const uluru = { lat: -25.344, lng: 131.036 };
  // The map, centered at Uluru
  //var uluru = JSON.parse(sluru);
  this._google_center = new google.maps.LatLng(37.38,  -121.98);
  const map = new google.maps.Map(document.getElementById("map"), {
    center: this._google_center,
    zoom: 0,
    tilt: 0,
    mapTypeId: "ROADMAP",
    disableDefaultUI: true,
    keyboardShortcuts: false,
    draggable: false,
    disableDoubleClickZoom: true,
    scrollwheel: false,
    streetViewControl: false,
    styles: "default", //this.options.mapOptions.styles,
    backgroundColor: '#FFFFFF' //this.options.mapOptions.backgroundColor
  });
}
function googleMapInitMap1(uluru) {
    // The location of Uluru
    //const uluru = { lat: -25.344, lng: 131.036 };
    // The map, centered at Uluru
    //var uluru = JSON.parse(sluru);
    
    uluru = {};
    uluru.lat = 37.38;
    uluru.lng = -121.98
    const map = new google.maps.Map(document.getElementById("map"), {
      zoom: 4,
      center: uluru,
    });
    
    // The marker, positioned at Uluru
    const marker = new google.maps.Marker({
      position: uluru,
      map: map,
    });
}
